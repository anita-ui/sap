sap.ui.define([], function() {
	"use strict";

	return {
		
		currentPending: function(docQty,conQty) {

			var newQty= docQty-conQty;
			var finalQty = parseFloat(newQty);
			console.log(finalQty);
			return finalQty;

		}
		

		
	};

});