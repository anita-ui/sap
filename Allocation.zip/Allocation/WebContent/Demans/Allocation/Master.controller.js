sap.ui.define([
		"DeManS/Demans/Allocation/BaseController",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/MessageBox",
		"sap/ui/Device"
	], function (BaseController, JSONModel, Filter, FilterOperator,MessageBox,Device) {
		"use strict";

		return BaseController.extend("DeManS.Demans.Allocation.Master", {

		onInit : function () {
			var oList=this.byId("list");
			this._oList=oList;
			jQuery.sap.require("jquery.sap.storage");
		
		//	this.getOwnerComponent().getRouter().getRoute("masterAllo").attachPatternMatched(this._onRouteMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
			
},
onAfterRendering:function(){
	this._onObjectMatched()

},	
_onObjectMatched:function(){
	//this._oList.removeSelections(true);
	var oList = this.byId("list");
	var oItem1 = oList.getItems()[0];
	
	oList.setSelectedItem(oItem1, true);
},
onUpdateFinished:function(oEvent){
	//this._oList.removeSelections(true);
	var oList = this.byId("list");
	var oItem = oList.getItems();
	oItem[0].firePress();

  
  },

      onBypassed: function() {	
	this.byId("list").removeSelections(true);
},
		onSearch : function (oEvent) {
		
			var sQuery = oEvent.getSource().getValue();
			
			  var oFilter = new sap.ui.model.Filter({ filters: [
				  
		          // filter for value 1
		          new sap.ui.model.Filter("Part_Descr", sap.ui.model.FilterOperator.Contains, sQuery),
		           
		          // filter for value 2
		          new sap.ui.model.Filter("Part_Number", sap.ui.model.FilterOperator.Contains, sQuery)
		 
		        ],
		        // set the OR or AND condition between the filters
		        // true for AND, and false for OR
		        // false by default
		        and: false
		     
		      });
			  var oBinding = this.byId("list").getBinding("items");     
		       
		      // apply filters
		      oBinding.filter(oFilter, sap.ui.model.FilterType.Application);
		    

			
		},
		

		    onRefresh : function () {
				this._oList.getBinding("items").refresh();
			},
			

			 onSelectionChange: function(oEvent){
				   
				   var oItem1 = oEvent.getSource();
				   console.log(oItem1);
				   var oCtx1 = oItem1.getBindingContext("masterView");
				   console.log(oCtx1);
				   this.getRouter().navTo("details",{
						detailID1 : oCtx1.getProperty("Part_Number")
				   });
			 }
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf Demans.PurchaseOrder.App
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf Demans.PurchaseOrder.App
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf Demans.PurchaseOrder.App
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf Demans.PurchaseOrder.App
*/
//	onExit: function() {
//
//	}
	
	});

});
	