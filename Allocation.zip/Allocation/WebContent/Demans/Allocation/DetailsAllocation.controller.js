sap.ui.define([
		"DeManS/Demans/Allocation/BaseController",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
         'sap/m/MessageBox',
		'sap/m/MessageToast',
	    'sap/m/MessagePopoverItem',
		'sap/m/MessagePopover',
        "DeManS/model/formatter"
	], function (BaseController,Controller,JSONModel,Filter,MessageBox,MessageToast,MessagePopoverItem,MessagePopover,formatter ) {
		"use strict";

		return BaseController.extend("DeManS.Demans.Allocation.DetailsAllocation", {
       
			formatter: formatter,


/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf Demans.PurchaseOrder.App
*/
onInit: function() {
	var oRouter = this.getRouter();
    oRouter.getRoute("details").attachPatternMatched(this._onRouteMatched, this);

    var F4Data = {
			Mode: null,
			ERROR: this.getErrorFields(),

		};

		var F4Data = new sap.ui.model.json.JSONModel(F4Data);
		 F4Data.setSizeLimit(9999);
		this.setModel(F4Data, "F4Data");
	},
	  _onRouteMatched: function(oEvent) {
           var that = this;
          var param = oEvent.getParameter("arguments");
          console.log(param);
          var oView = this.getView();
          var oModel = oView.getModel("qoDetailViewHeader")
          if (oModel !== undefined) {
              oModel.setData(null);
          }

//          var that = this;        
//          var sId = oView.byId("idProductsTable");          
          var sComponentName = this.getOwnerComponent().getMetadata().getComponentName();
          console.log(sComponentName);
          var localJSON = $.sap.getModulePath(sComponentName, "/model/Data.json");
          console.log(localJSON);
          var oModel = new sap.ui.model.json.JSONModel(localJSON);
  
          console.log(oModel);
          oModel.attachRequestCompleted(function() {  
//        	  var ModelNEW= oEvent.getSource();
//        	  sap.ui.getCore().setModel(ModelNEW);
              var data = oModel.getData().Allocation;
        
              var oData = data.filter(function(ele) {
                  return ele.Part_Number === param.detailID1;
            });
               var displayModel =new sap.ui.model.json.JSONModel(oData);
             
//               sId.setModel(displayModel, "qoDetailView");
               that.getView().setModel(displayModel, "qoDetailViewHeader");
//              this.getView().byId("idProductsTable").setModel(displayModel, "qoDetailView");
              /*sId1.setModel(displayModel, "soDetailView");*/


        });
      },
      /* .............. Check Mandatory Fields........ */
		mandatoryCheck: function () {
			var Header = this.getView().getModel("qoDetailViewHeader").getData();
			var that = this;
			var sModel = that.getView().getModel("F4Data");
			var Error = false;
			var Message = {
				Error: false
				
			};
			var F4Data = this.getModel("F4Data").getData();
			F4Data.ERROR = this.getErrorFields();
			var ErrorModel = [];
        	var tableItems=this.getView().byId("idProductsTable").getItems();
			for(var i=0; i<tableItems.length; i++){
			var openDocQty=	this.getView().byId("idProductsTable").getItems()[i].getAggregation("cells")[3].getValue();
			var confirmQty=this.getView().byId("idProductsTable").getItems()[i].getAggregation("cells")[4].getValue();
			var pendingQty=this.getView().byId("idProductsTable").getItems()[i].getAggregation("cells")[5].getValue();
			var pendingQ=openDocQty-confirmQty;
	
			if(openDocQty<confirmQty||confirmQty==""){
				
				sap.ui.getCore().byId(this.getView().byId("idProductsTable").getItems()[i].getAggregation("cells")[4].getId()).setValueState("Error");	
				sap.ui.getCore().byId(this.getView().byId("idProductsTable").getItems()[i].getAggregation("cells")[4].getId()).setValueStateText("Please enter Customer");
				Error === true
				ErrorModel.push({
					type:"Error",
					title: "Please enter Mandtory fields",
					description: "Please Fill Confirm Qty"
				});
			
			
			}
         else{
        	 sap.ui.getCore().byId(this.getView().byId("idProductsTable").getItems()[i].getAggregation("cells")[4].getId()).setValueState("None");
        	
        	 
        	 if( i==tableItems.length-1){
        			
    				
    				
        	 sap.m.MessageBox.success("Allocation Change Successfully.", {
     		    title: "Success",                                    
     		                                      // default
     		    styleClass: "",                                      // default
     		    initialFocus: null,                                  // default
     		    textDirection: sap.ui.core.TextDirection.Inherit     // default
     		});
        	 }
			}
			}
			
    		Message.Error = Error;
			this.getView().getModel("F4Data").setData(F4Data);
			if (ErrorModel.length > 0) {
				this.openMsgPopover(ErrorModel);
			}
			return Message;
		},
  	getErrorFields: function () {
		return {
			confirm_qty: {
				STATE: "None",
				MESSAGE: null
			}
		};
	},
      openMsgPopover: function (Error) {
			var oButton = this.getView().byId("messagePopoverBtn");
			var that = this;
			var oMessageTepmplate = new MessagePopoverItem({
				type: '{type}',
				title: '{title}',
				description: '{description}'
			});
			var oMessagePopover = new MessagePopover({
				items: {
					path: "/",
					template: oMessageTepmplate
				},
				afterClose: function () {
					that.getView().byId("messagePopoverBtn").setType("Accept");
				}
			});
			var ErrorMode = new JSONModel();
			ErrorMode.setData(Error);
			oMessagePopover.setModel(ErrorMode);
			oMessagePopover.openBy(oButton);
			this.getView().byId("messagePopoverBtn").setType("Reject");
		},
//      handleMessagePopoverPress: function (oEvent) {
//			oMessagePopover.toggle(oEvent.getSource());
//		},

      /*----- Table Personalization ------ */
      
      onPersoButtonPressed:function(event) {
             var that = this;
              var List = that.byId("List");
              console.log(List);
              var popOver = this.byId("popOver");
              if (List !== undefined) {
                  List.destroy();
              }
              if (popOver !== undefined) {
                  popOver.destroy();
              }
              /*----- PopOver on Clicking ------ */
              var popover = new sap.m.Popover(this.createId("popOver"), {
                  showHeader: true,
                  showFooter: true,
                  placement: sap.m.PlacementType.Bottom,
                  content: []
              }).addStyleClass("sapMOTAPopover sapTntToolHeaderPopover");
              /*----- Adding List to the PopOver -----*/
              var oList = new sap.m.List(this.createId("List"), {});
              this.byId("popOver").addContent(oList);
              var openDetailsTable = this.getView().byId("idProductsTable");
              console.log(openDetailsTable);
             var columnHeader = openDetailsTable.getColumns();
              var openDetailsColumns = [];
              for (var i = 0; i < columnHeader.length; i++) {
                  var hText = columnHeader[i].getAggregation("header").getProperty("text");
                  var columnObject = {};
                  columnObject.column = hText;
                  openDetailsColumns.push(columnObject);
              }
              var oModel1 = new sap.ui.model.json.JSONModel({
                  list: openDetailsColumns
              });

              var itemTemplate = new sap.m.StandardListItem({
                  title: "{oList>column}"
              });
              oList.setMode("MultiSelect");
              oList.setModel(oModel1);
              sap.ui.getCore().setModel(oModel1, "oList");

              var oBindingInfo = {
                  path: 'oList>/list',
                  template: itemTemplate
              };
              oList.bindItems(oBindingInfo);

              var footer = new sap.m.Bar({
                  contentLeft: [],
                  contentMiddle: [new sap.m.Button({
                          text: "Cancel",
                          press: function() {
                              that.onPressCancel();
                          }
                      }),
                      new sap.m.Button({
                          text: "Ok",
                          press: function() {
                              that.onPressOK();
                          }
                      })
                  ]

              });

              this.byId("popOver").setFooter(footer);
              var oList1 = this.byId("List");
              var table = this.byId("idProductsTable").getColumns();

              /*=== Update finished after list binded for selected visible columns ==*/
              oList1.attachEventOnce("updateFinished", function() {
                  var a = [];
                  for (var j = 0; j < table.length; j++) {
                      var list = oList1.oModels.undefined.oData.list[j].column;
                      a.push(list);
                      var Text = table[j].getHeader().getProperty("text");
                      var v = table[j].getProperty("visible");
                      if (v === true) {
                          if (a.indexOf(Text) > -1) {
                              var firstItem = oList1.getItems()[j];
                              oList1.setSelectedItem(firstItem, true);
                          }
                      }
                  }
              });
              popover.openBy(event.getSource());
          },
    /*================Row Read =================*/
          onListUpdateFinished: function(oEvent) {
  			var sTitle = "Rows Read",
  			oTable = this.getView().byId("idProductsTable");
  			
  			if(oTable.getBinding("items").isLengthFinal()) {
  				var iCount = oEvent.getParameter("total"),
  					iItems = oTable.getItems().length;
  					sTitle += "(" + iCount + ")";
  			}
  		this.getView().byId("lineItemsHeader").setText(sTitle);
  			

  		},
       
      
      
      	 
          /*================ Closing the PopOver =================*/
          onPressCancel: function() {
              this.byId("popOver").close();
          },

          /*============== Saving User Preferences ==================*/
          onPressOK: function() {
              var that = this;
              var oList = this.byId("List");
              var array = [];
              var items = oList.getSelectedItems();
         
              // Getting the Selected Columns header Text.
              for (var i = 0; i < items.length; i++) {
                  var item = items[i];
                  var context = item.getBindingContext("oList");
                  var obj = context.getProperty(null, context);
                  var column = obj.column;
                  array.push(column);
              }

              /*---- Displaying Columns Based on the selection of List ----*/
              var table = this.byId("idProductsTable").getColumns();
              for (var j = 0; j < table.length; j++) {
                  var Text = table[j].getHeader().getProperty("text");
                  var Column = table[j].getId();
                  var columnId = this.getView().byId(Column);
                  if (array.indexOf(Text) > -1) {
                      columnId.setVisible(true);
                  } else {
                      columnId.setVisible(false);
                  }
              }

              this.byId("popOver").close();

          },
      
	   onSave : function(Event){
//		   this.mandatoryCheck();
	
		   var  partno= this.getView().byId("idPartno").getValue();
			var tableItems=this.getView().byId("idProductsTable").getItems();
			for(var j=0; j<tableItems.length; j++){
		   var orderno=this.getView().byId("idProductsTable").getItems()[j].getAggregation("cells")[1].getValue();
		   var itemno=this.getView().byId("idProductsTable").getItems()[j].getAggregation("cells")[2].getValue();
		   var cnfQty=this.getView().byId("idProductsTable").getItems()[j].getAggregation("cells")[4].getValue();
			}
		   var  payload={
					 "PART_NO":partno,
					 "items":[
					 {
					 "ITEM_NO":itemno,
					 "CONFIRM_QTY":cnfQty,
					 "SO_NO":orderno
					 },
					 {
						 "ITEM_NO":itemno,
						 "CONFIRM_QTY":cnfQty,
						 "SO_NO":orderno
					 }
					 ]
					 }
	
},
	onCancel : function(){
		
		sap.m.MessageBox.confirm("Are you sure want to Cancel, unsaved data will be lost." +
				"Please Confirm", {
		    title: "Cancel",			
		    onClose: function(oAction){		    	
		    	 var oRouter = this.getRouter();
				  oRouter.navTo("details");
		         },                                       // default
		    styleClass: "",                                      // default
		    initialFocus: null,                                  // default
		    textDirection: sap.ui.core.TextDirection.Inherit     // default
		});
		}
		
	
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf Demans.PurchaseOrder.App
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf Demans.PurchaseOrder.App
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf Demans.PurchaseOrder.App
*/
//	onExit: function() {
//
//	}
			
		});
});